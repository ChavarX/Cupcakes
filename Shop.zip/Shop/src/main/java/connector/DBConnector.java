package connector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnector
{
    private static String driver = "com.mysql.jdbc.Driver";
    private static String url = "jdbc:mysql://138.68.78.97:3306/shop";
    private static String user = "chavar";
    private static String password = "14101996Chrmh";
    private static Connection conn = null;

    public static Connection getConnection()
    {
        if (conn == null)
        {
            try
            {
                Class.forName(driver);
                conn = DriverManager.getConnection(url, user, password);
            }
            catch (ClassNotFoundException ex)
            {
                ex.printStackTrace();
            }
            catch (SQLException ex)
            {
                ex.printStackTrace();
            }
        }
        
        return conn;
    }
}
